# My Portfolio
A personal portfolio website built with React, smooth scroll, and animations.